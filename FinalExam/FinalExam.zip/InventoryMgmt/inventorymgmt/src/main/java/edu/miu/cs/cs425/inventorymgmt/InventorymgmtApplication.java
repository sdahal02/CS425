package edu.miu.cs.cs425.inventorymgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorymgmtApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventorymgmtApplication.class, args);
    }

}
