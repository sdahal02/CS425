package edu.miu.cs.cs425.inventorymgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HcmcApplicationTests {

    @Test
    void contextLoads() {
    }

}
